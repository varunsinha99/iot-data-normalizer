# IoT Data Normalizer

A small Python utility that converts manufacturing IoT telemetry data from two different JSON schemas into a single, unified format. Built as part of a Deloitte Technology Job Simulation (via Forage).

## Problem

In a real manufacturing environment, telemetry data often arrives in inconsistent formats — different devices, vendors, or legacy systems each send data shaped differently. Before this data can be stored, queried, or visualized (e.g. in a monitoring dashboard), it needs to be normalized into one consistent schema.

This script handles two incoming formats and converts both into a single target schema.

## Input Formats

**Format 1** — flat structure, slash-delimited location string, Unix epoch timestamp (ms):
```json
{
    "deviceID": "dh28dslkja",
    "deviceType": "LaserCutter",
    "timestamp": 1624445837783,
    "location": "japan/tokyo/keiyō-industrial-zone/daikibo-factory-meiyo/section-1",
    "operationStatus": "healthy",
    "temp": 22
}
```

**Format 2** — nested structure, ISO 8601 timestamp string:
```json
{
    "device": { "id": "dh28dslkja", "type": "LaserCutter" },
    "timestamp": "2021-06-23T10:57:17.783Z",
    "country": "japan",
    "city": "tokyo",
    "area": "keiyō-industrial-zone",
    "factory": "daikibo-factory-meiyo",
    "section": "section-1",
    "data": { "status": "healthy", "temperature": 22 }
}
```

## Output Format

Both inputs are converted to this unified schema:

```json
{
    "deviceID": "dh28dslkja",
    "deviceType": "LaserCutter",
    "timestamp": 1624445837783,
    "location": {
        "country": "japan",
        "city": "tokyo",
        "area": "keiyō-industrial-zone",
        "factory": "daikibo-factory-meiyo",
        "section": "section-1"
    },
    "data": {
        "status": "healthy",
        "temperature": 22
    }
}
```

## How it works

- `convertFromFormat1()` — splits the slash-delimited `location` string into a structured object, and remaps flat fields (`operationStatus`, `temp`) into the nested `data` object.
- `convertFromFormat2()` — parses the ISO 8601 timestamp and converts it to Unix epoch milliseconds (to match Format 1's timestamp convention), and flattens the nested `device` object.
- `main()` — detects which format the input is in (checks for the presence of a `device` key) and routes it to the correct converter.

## Tests

Three unit tests (via Python's built-in `unittest`) verify both converters produce output matching the expected result:

```bash
python main.py
```

```
...
----------------------------------------------------------------------
Ran 3 tests in 0.010s

OK
```

## Tech

Python 3, standard library only (`json`, `unittest`, `datetime`) — no external dependencies.
